RMS CREDITS Android App - Source Project

මෙය සූදානම් කළ Android Studio project එකකි. මෙය APK ගොනුවක් නොවේ.

APK එක සෑදීමට:
1. පරිගණකයක Android Studio ස්ථාපනය කරන්න.
2. Android Studio > Open තෝරා මෙම project folder එක විවෘත කරන්න.
3. Gradle sync අවසන් වනතුරු රැඳී සිටින්න.
4. Build > Build Bundle(s) / APK(s) > Build APK(s) තෝරන්න.
5. app/build/outputs/apk/debug/app-debug.apk ගොනුව ලැබේ.
6. APK එක Android phone එකට copy කර install කරන්න.

සටහන:
- Loan සහ collection දත්ත දැනට app එකේ WebView local storage තුළ පමණක් තබා ගනී.
- App data clear කළහොත් හෝ app එක uninstall කළහොත් දත්ත මැකිය හැක.
- නිතර CSV backup ලබාගන්න.
- මෙය මුල් prototype එකකි; සැබෑ ව්‍යාපාරික භාවිතයට පෙර ගණනය කිරීම් සහ backup/restore පරීක්ෂා කරන්න.
